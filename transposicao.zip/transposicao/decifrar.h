#include "util.h"

std::string decipher(std::string, std::string);
