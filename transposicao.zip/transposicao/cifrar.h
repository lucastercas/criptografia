#include "util.h"

std::string cipher(std::string, std::string);
